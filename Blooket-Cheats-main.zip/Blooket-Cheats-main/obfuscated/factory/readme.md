# Factory Cheats

## [Choose Blook](chooseBlook.js)
Gives you a blook
## [Free Upgrades](freeUpgrades.js)
Sets upgrade prices to 0 for all current blooks

## [Max Blooks](maxBlooks.js)
Maxes out all your blooks' levels

## [Remove Glitches](removeGlitches.js)
Removes all enemy glitches

## [Send Glitch](sendGlitch.js)
Sends a random glitch

## [Set All Mega Bot](setAllMegaBot.js)
Sets all your blooks to maxed out Mega Bots

## [Set Cash](setCash.js)
Sets amount of cash you have