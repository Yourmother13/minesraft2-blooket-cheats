# Blook Rush Cheats

## [Set Blooks](setBlooks.js)
Sets amount of blooks you or your team has

## [Set Defense](setDefense.js)
Sets amount of defense you or your team has (Max 4)